﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint1Game.Sound
{
    public class HurrySoundManager
    {
        private static HurrySoundManager instance = new HurrySoundManager();
        public static HurrySoundManager Instance
        {
            get
            {
                return instance;
            }
        }
        private HurrySoundManager()
        {

        }
        public void CheckForHurry()
        {
            if (GameUtilities.GameObjectManager.CurrentMario.Destination.X < GameUtilities.FlagLine*GameUtilities.BlockSize && 
                MarioAttributes.Time == 100)
            {
                SoundManager.Instance.PlayHurryOverworldSong();
            }
            else if(GameUtilities.GameObjectManager.CurrentMario.Destination.X > GameUtilities.LevelEndLine * GameUtilities.BlockSize && 
                MarioAttributes.Time == 100)
            {
                SoundManager.Instance.PlayHurryUnderworldSong();
            }
            else
            {
                SoundManager.Instance.ResumeSound();
            }

            this.ToString();
        }
    }
}
