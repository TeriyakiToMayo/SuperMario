﻿using Microsoft.Xna.Framework.Media;
using Sprint1Game.Interfaces;
using Sprint1Game.Sound;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint1Game.Commands
{
    class EnterCommand : ICommand
    {
        private Game1 game;

        public EnterCommand(Game1 game)
        {
            this.game = game;
        }
        public void Execute()
        {
            switch (game.State.Type)
            {
                case GameStates.Title:
                    game.State.Proceed();
                    break;
                case GameStates.Playing:
                    if(GameUtilities.GameObjectManager.CurrentMario.State.MarioPosture != MarioState.MarioPostureEnums.Dead)
                    {
                        game.State.Pause();
                        SoundManager.Instance.PauseSound();
                    }
                    break;
                case GameStates.Pause:
                    game.State.Proceed();
                    SoundManager.Instance.ResumeSound();
                    break;
                default:
                    break;
            }
            
        }
    }
}
