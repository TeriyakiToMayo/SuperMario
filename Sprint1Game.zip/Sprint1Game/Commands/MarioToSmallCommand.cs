﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sprint1Game.Interfaces;

namespace Sprint1Game
{
    class MarioToSmallCommand : ICommand
    {
        private IMario mario;     

        public MarioToSmallCommand(IMario mario)
        {
            this.mario = mario;
        }
        public void Execute()
        {
            mario.State.ChangeSizeToSmall(); 
        }
    }
}
