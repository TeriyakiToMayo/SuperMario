﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sprint1Game.Interfaces;

namespace Sprint1Game
{
    class MarioToBigCommand : ICommand
    {
        private IMario mario;   

        public MarioToBigCommand(IMario mario)
        {
            this.mario = mario;
        }
        public void Execute()
        {
            mario.State.ChangeSizeToBig();
        }
    }
}
