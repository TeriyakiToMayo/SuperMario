﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sprint1Game.Interfaces;

namespace Sprint1Game
{
    class MarioToFireCommand : ICommand
    {
        private IMario mario;
        
        public MarioToFireCommand(IMario mario)
        {
            this.mario = mario;
        }
        public void Execute()
        {

            mario.State.ChangeFireMode();

        }
    }
}
