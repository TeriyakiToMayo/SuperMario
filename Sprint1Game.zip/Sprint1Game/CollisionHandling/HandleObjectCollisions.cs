﻿using Sprint1Game.Interfaces;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint1Game.CollisionHandling
{
    public static class HandleObjectCollisions
    {
        public static void HandleCollisions(ICollisionHandler collisionHandler, IMario mario, Collection<IGameObject> blockList, Collection<IGameObject> enemyList, Collection<IGameObject> itemList, Collection<IGameObject> pipeList, Collection<IGameObject> fireBallList)
        {
            HandleMarioCollisions(collisionHandler, mario, blockList, enemyList, itemList, pipeList);
            HandleEnemyCollisions(collisionHandler, blockList, enemyList, pipeList);
            HandleItemCollisions(collisionHandler, blockList, itemList, pipeList);
            HandleFireBallCollisions(collisionHandler, blockList, enemyList, pipeList, fireBallList);
        }
        private static void HandleMarioCollisions(ICollisionHandler collisionHandler, IMario mario, Collection<IGameObject> blockList, Collection<IGameObject> enemyList, Collection<IGameObject> itemList, Collection<IGameObject> pipeList)
        {
            foreach (IGameObject obj in blockList)
            {
                collisionHandler.DetectMarioBlockCollisions(mario, obj);
            }
            collisionHandler.HandleMarioBlockCollisions();
            foreach (IGameObject obj in enemyList)
            {
                collisionHandler.HandleCollision(mario, obj);
            }
            foreach (IGameObject obj in itemList)
            {
                collisionHandler.HandleCollision(mario, obj);
            }
            foreach (IGameObject obj in pipeList)
            {
                collisionHandler.HandleCollision(mario, obj);
            }
        }

        private static void HandleEnemyCollisions(ICollisionHandler collisionHandler, Collection<IGameObject> blockList, Collection<IGameObject> enemyList, Collection<IGameObject> pipeList)
        {
            for (int i = 0; i < enemyList.Count; i++)
            {
                foreach (IGameObject obj in blockList)
                {
                    collisionHandler.HandleCollision(enemyList[i], obj);
                }
                for (int j = i + 1; j < enemyList.Count; j++)
                {
                    collisionHandler.HandleCollision(enemyList[i], enemyList[j]);
                }
                foreach (IGameObject obj in pipeList)
                {
                    collisionHandler.HandleCollision(enemyList[i], obj);
                }
            }
        }

        private static void HandleItemCollisions(ICollisionHandler collisionHandler, Collection<IGameObject> blockList, Collection<IGameObject> itemList, Collection<IGameObject> pipeList)
        {
            for (int i = 0; i < itemList.Count; i++)
            {
                foreach (IGameObject obj in blockList)
                {
                    collisionHandler.HandleCollision(itemList[i], obj);
                }
                foreach (IGameObject obj in pipeList)
                {
                    collisionHandler.HandleCollision(itemList[i], obj);
                }
            }
        }

        private static void HandleFireBallCollisions(ICollisionHandler collisionHandler, Collection<IGameObject> blockList, Collection<IGameObject> enemyList, Collection<IGameObject> pipeList, Collection<IGameObject> fireBallList)
        {
            for (int i = 0; i < fireBallList.Count; i++)
            {
                foreach (IGameObject obj in blockList)
                {
                    collisionHandler.HandleCollision(fireBallList[i], obj);
                }
                foreach (IGameObject obj in pipeList)
                {
                    collisionHandler.HandleCollision(fireBallList[i], obj);
                }
                foreach (IGameObject obj in enemyList)
                {
                    collisionHandler.HandleCollision(fireBallList[i], obj);
                }
            }
        }
    }
}
