﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint1Game.CollisionHandling
{
    public static class CollisionSide
    {
        public enum Object2Side { Top, Right, Bottom, Left, NoCollision};
    }
}
