﻿using Sprint1Game.Interfaces;

namespace Sprint1Game.CollisionHandling
{
    internal class GMushroomBlockCollisionTop : ICollisionCommand
    {
    }
}