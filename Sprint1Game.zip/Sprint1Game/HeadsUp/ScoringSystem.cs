﻿using Microsoft.Xna.Framework;
using Sprint1Game.Animation;
using Sprint1Game.GameObjects;
using Sprint1Game.Interfaces;
using Sprint1Game.Sound;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Sprint1Game.GameObjects.GameObjectType;

namespace Sprint1Game.HeadsUp
{
    public class ScoringSystem
    {
        private const int BreakingBlockScore = 50;
        private const int ItemCollectedScore = 1000;
        private const int CoinCollectedScore = 200;
        private const int SecondBonusScore = 10;
        private const int EnemyBelowBlockHitScore = 100;
        private const int SpecialGoombaHitScore = 100;
        private const int SpecialKoopaHitScore = 200;
        private const int Pole1Score = 5000;
        private const int Pole2Score = 2000;
        private const int Pole3Score = 800;
        private const int Pole4Score = 400;
        private const int Pole5Score = 100;
        private const int Pole1Cutoff = 1;
        private const int Pole2Cutoff = 3;
        private const int Pole3Cutoff = 4;
        private const int Pole4Cutoff = 5;

        private int score = 0;
        public int Score { get { return score; } }
        private ScoringComboManager comboManager;
        private List<IGameObject> poleParts;

        private static ScoringSystem instance = new ScoringSystem();
        public static ScoringSystem Instance { get { return instance; } }
        private ScoringSystem()
        {
            this.poleParts = new List<IGameObject>();
        }
        public void RegisterMario(IMario mario)
        {
            this.comboManager = new ScoringComboManager(mario);
        }
        public IGameObject RegisterPole(IGameObject pole)
        {
            this.poleParts.Add(pole);
            return pole;
        }
        public void ResetScore()
        {
            score = 0;
        }

        public void AddPointsForBreakingBlock()
        {
            score += BreakingBlockScore;
        }
        public void AddPointsForCollectingItem(IGameObject item)
        {
            score += ItemCollectedScore;
            CreateNewScoreAnimation(item, ItemCollectedScore);
        }
        public void AddPointsForCoin()
        {
            score += CoinCollectedScore;
        }
        public void AddPointsForRestTime()
        {
            score += SecondBonusScore;
            SoundManager.Instance.PlayCoinSound();
        }
        public void AddPointsForStompingEnemy(IGameObject enemy)
        {
            int scoreToAdd = comboManager.DetermineStompSequence();
            score += scoreToAdd;
            CreateNewScoreAnimation(enemy, scoreToAdd);
        }
        public void AddPointsForEnemyBelowBlockHit(IGameObject enemy)
        {
            int scoreToAdd = EnemyBelowBlockHitScore;
            score += scoreToAdd;
            CreateNewScoreAnimation(enemy, scoreToAdd);
        }
        public void AddPointsForSpecialGoombaHit(IGameObject goomba)
        {
            int scoreToAdd = SpecialGoombaHitScore;
            score += scoreToAdd;
            CreateNewScoreAnimation(goomba, scoreToAdd);
        }
        public void AddPointsForSpecialKoopaHit(IGameObject koopa)
        {
            int scoreToAdd = SpecialKoopaHitScore;
            score += scoreToAdd;
            CreateNewScoreAnimation(koopa, scoreToAdd);
        }
        public void AddPointsForInitiatingShell(IGameObject enemy)
        {
            int scoreToAdd = comboManager.DetermineShellInitializationSequence(enemy);
            score += scoreToAdd;
            CreateNewScoreAnimation(enemy, scoreToAdd);
        }
        public void AddPointsForEnemyHitByShell(IGameObject enemy)
        {
            int scoreToAdd = comboManager.DetermineShellHitSequence(enemy);
            score += scoreToAdd;
            CreateNewScoreAnimation(enemy, scoreToAdd);
        }
        public void AddPointsForFinalPole(Rectangle marioDestination)
        {
            int scoreToAdd = Pole5Score;
            if (marioDestination.Y < poleParts[Pole1Cutoff].Destination.Y)
            {
                scoreToAdd = Pole1Score;
            }
            else if (marioDestination.Y < poleParts[Pole2Cutoff].Destination.Y)
            {
                scoreToAdd = Pole2Score;
            }
            else if (marioDestination.Y < poleParts[Pole3Cutoff].Destination.Y)
            {
                scoreToAdd = Pole3Score;
            }
            else if (marioDestination.Y < poleParts[Pole4Cutoff].Destination.Y)
            {
                scoreToAdd = Pole4Score;
            }
            score += scoreToAdd;
            CreateNewScoreAnimation(marioDestination, poleParts[Pole4Cutoff].Destination, scoreToAdd);
        }

        public void SetMarioAirbourneToFalse()
        {
            comboManager.IsMarioAirbourne = false;
        }
        public void SetMarioEnemyHitThisIterationToFalse()
        {
            comboManager.HitEnemyAlreadyThisIteration = false;
        }

        private static void CreateNewScoreAnimation(IGameObject obj, int scoreToDisplay)
        {
            Rectangle objDestination = obj.Destination;
            Vector2 location = new Vector2(objDestination.X, objDestination.Y);
            IAnimationInGame scoreAnimation = new ScoreTextAnimation(location, "" + scoreToDisplay);
            scoreAnimation.StartAnimation();
        }
        private static void CreateNewScoreAnimation(Rectangle marioDestination, Rectangle poleDestination, int scoreToDisplay)
        {
            IAnimationInGame scoreAnimation = new PoleScoreTextAnimation(marioDestination, poleDestination, "" + scoreToDisplay);
            scoreAnimation.StartAnimation();
        }
    }
}
