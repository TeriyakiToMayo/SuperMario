﻿using Sprint1Game.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint1Game.HeadsUp
{
    public class ScoringComboManager
    {
        private const int InitialStompScore = 100;
        private const int DoubleStompScore = 200;
        private const int InitialShellHitScore = 500;
        private const int InitialShellKickScore = 400;
        private const int InAirAfterMakingShellKickScore = 500;
        private const int Stomp2ComboScore = 200;
        private const int Stomp3ComboScore = 400;
        private const int Stomp4ComboScore = 500;
        private const int Stomp5ComboScore = 800;
        private const int Stomp6ComboScore = 1000;
        private const int Stomp7ComboScore = 2000;
        private const int Stomp8ComboScore = 4000;
        private const int Stomp9ComboScore = 5000;
        private const int ShellHit2ComboScore = 800;
        private const int ShellHit3ComboScore = 1000;
        private const int ShellHit4ComboScore = 2000;
        private const int ShellHit5ComboScore = 4000;
        private const int ShellHit6ComboScore = 5000;

        private Dictionary<IGameObject, int> koopaKickedShells;
        private int stompedEnemiesInSequence;
        public bool HitEnemyAlreadyThisIteration { get; set; } = false;
        private bool isMarioInAir;
        public bool IsMarioAirbourne
        {
            get { return isMarioInAir; }
            set
            {
                if (!value)
                    stompedEnemiesInSequence = 0;
                isMarioInAir = value;
            }
        }

        public ScoringComboManager(IMario mario)
        {
            this.stompedEnemiesInSequence = 0;
            this.koopaKickedShells = new Dictionary<IGameObject, int>();
            this.isMarioInAir = mario.IsInAir;
        }

        public int DetermineDoubleStompSequence()
        {
            int scoreToAdd = InitialStompScore;
            if (HitEnemyAlreadyThisIteration)
                scoreToAdd = DoubleStompScore;
            HitEnemyAlreadyThisIteration = true;
            return scoreToAdd;
        }

        public int DetermineStompSequence()
        {
            int scoreToAdd = DetermineDoubleStompSequence();
            if (scoreToAdd == InitialStompScore && isMarioInAir)
            {
                switch (stompedEnemiesInSequence)
                {
                    case 0:
                        scoreToAdd = InitialStompScore;
                        break;
                    case 1:
                        scoreToAdd = Stomp2ComboScore;
                        break;
                    case 2:
                        scoreToAdd = Stomp3ComboScore;
                        break;
                    case 3:
                        scoreToAdd = Stomp4ComboScore;
                        break;
                    case 4:
                        scoreToAdd = Stomp5ComboScore;
                        break;
                    case 5:
                        scoreToAdd = Stomp6ComboScore;
                        break;
                    case 6:
                        scoreToAdd = Stomp7ComboScore;
                        break;
                    case 7:
                        scoreToAdd = Stomp8ComboScore;
                        break;
                    case 8:
                        scoreToAdd = Stomp9ComboScore;
                        break;
                    case 9:
                        MarioAttributes.MarioLife++;
                        break;
                    default:
                        break;
                }
            }
            isMarioInAir = true;
            stompedEnemiesInSequence++;
            return scoreToAdd;
        }

        public int DetermineShellHitSequence(IGameObject koopa)
        {
            int scoreToAdd = InitialShellHitScore;
            switch (koopaKickedShells[koopa])
            {
                case 0:
                    scoreToAdd = InitialShellHitScore;
                    break;
                case 1:
                    scoreToAdd = ShellHit2ComboScore;
                    break;
                case 2:
                    scoreToAdd = ShellHit3ComboScore;
                    break;
                case 3:
                    scoreToAdd = ShellHit4ComboScore;
                    break;
                case 4:
                    scoreToAdd = ShellHit5ComboScore;
                    break;
                case 5:
                    scoreToAdd = ShellHit6ComboScore;
                    break;
                case 6:
                    MarioAttributes.MarioLife++;
                    break;
                default:
                    break;
            }
            koopaKickedShells[koopa]++;
            return scoreToAdd;
        }

        public int DetermineShellInitializationSequence(IGameObject koopa)
        {
            int scoreToAdd = InitialShellKickScore;
            if (!koopaKickedShells.ContainsKey(koopa))
                koopaKickedShells.Add(koopa, 0);
            if (isMarioInAir)
                scoreToAdd = InAirAfterMakingShellKickScore;
            return scoreToAdd;
        }
    }
}
