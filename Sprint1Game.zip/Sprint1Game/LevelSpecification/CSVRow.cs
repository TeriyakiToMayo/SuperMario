﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Sprint1Game.LevelSpecification
{
    public class CSVRow : List<string>
    {
        public string LineText { get; set; }
    }
}
