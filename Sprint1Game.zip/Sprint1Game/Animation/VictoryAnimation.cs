﻿using Microsoft.Xna.Framework;
using Sprint1Game.HeadsUp;
using Sprint1Game.Interfaces;
using Sprint1Game.Sound;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint1Game.Animation
{
    public class VictoryAnimation : IAnimation
    {
        public AnimationState State { get; set; } = AnimationState.NotStart;

        private IMario mario_;
        private IItem flag_;

        private int stage = 1;
        private int counter = 0;
        private int maxCount = 1;

        private const int ground = 11;
        private const int castleGate = 204;
        private const int downSpeed = 1;

        public VictoryAnimation(IMario mario, IItem flag)
        {
            this.mario_ = mario;
            mario_.Acceleration = new Vector2(GameUtilities.StationaryAcceleration, GameUtilities.StationaryAcceleration);
            mario_.Velocity = new Vector2(GameUtilities.StationaryVelocity, downSpeed);
            SoundManager.Instance.PlayFlagPoleSound();
            this.flag_ = flag;
            flag_.Velocity = new Vector2(GameUtilities.StationaryVelocity, downSpeed);
        }


        public void Update()
        {
            if (State != AnimationState.IsPlaying)
            {
                return;
            }

            switch (stage)
            {
                case 1:
                    if (!mario_.IsInAir)
                    {
                        mario_.Velocity = new Vector2(GameUtilities.StationaryVelocity, GameUtilities.StationaryVelocity);
                        mario_.Acceleration = new Vector2(GameUtilities.StationaryAcceleration, GameUtilities.Gravity);
                    }
                    if(flag_.Location.Y >= ground * GameUtilities.BlockSize)
                    {
                        flag_.Velocity = new Vector2(GameUtilities.StationaryVelocity, GameUtilities.StationaryVelocity);
                        flag_.Location = new Vector2(flag_.Location.X, ground * GameUtilities.BlockSize);
                        
                    }

                    if (!mario_.IsInAir && flag_.Location.Y == ground * GameUtilities.BlockSize)
                    {
                        stage++;
                    }
                    break;
                case 2:
                    mario_.State.ChangeToRight();
                    if(mario_.Destination.X >= castleGate * GameUtilities.BlockSize)
                    {
                        mario_.State.ChangeToLeft();
                        mario_.State.StateSprite = BlockSpriteFactory.Instance.CreateHiddenBlockSprite();
                        stage++;
                    }
                    break;
                case 3:
                    if (MarioAttributes.Time == 0)
                    {
                        stage++;
                    }else
                    {
                        counter++;
                        if (counter == maxCount)
                        {
                            ScoringSystem.Instance.AddPointsForRestTime();
                            MarioAttributes.Time--;
                            counter = 0;
                        }
                    }
                    
                    break;
                default:
                    Game1 game = (Game1)GameUtilities.Game;
                    game.Reset();
                    game.State.Proceed();
                    MarioAttributes.MarioLife = GameUtilities.MarioInitalLife;
                    MarioAttributes.UpdateHighestScore();
                    CoinSystem.Instance.ResetCoin();
                    ScoringSystem.Instance.ResetScore();
                    MarioAttributes.ClearTimer();
                    break;
            }
        }
    }
}
