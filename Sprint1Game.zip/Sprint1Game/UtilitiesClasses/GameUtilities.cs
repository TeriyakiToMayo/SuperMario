﻿using Microsoft.Xna.Framework;
using Sprint1Game.GameObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint1Game
{
    public static class GameUtilities
    {
        public static AbstractGame Game { get; set; }
        public static TheGameObjectManager GameObjectManager { get; set; }
        public static int SpriteSize { get; set; } = 1;
        public static int HorizonLine { get; set; } = 300;
        public static int Number { get; set; } = 240;
        public static int Origin { get; } = 0;
        public static int StationaryVelocity { get; } = 0;
        public static int StationaryAcceleration { get; } = 0;
        public static int SinglePixel { get; } = 1;
        public static int MarioBounceVelocity { get; } = -2;
        public static int KoopaShellVelocity { get; } = 4;
        public static int FireBallPopVelocity { get; } = 3;
        public static int MarioSprintSpeed { get; } = 4;
        public static float MarioRegularSpeed { get; } = 2.5f;
        public static float MarioRegularAccel { get; } = .25f;
        public static float BrickBlockFallingSpeed { get; } = 0.5f;
        public static float GoombaBounceVelocity { get; } = 3.5f;
        public static float Gravity { get; } = .48f;
        public static float GoombaHSpeed { get; } = .75f;
        public static float FlowerGravity { get; } = 0.5f;
        public static int ScreenWidth { get; } = 480;
        public static int ScreenHeight { get; } = 240;

        public static int BlockSize { get; } = 16;

        public static int LevelEndLine { get; } = 208;
        public static int UndergroundEndLine { get; } = 238;

        public static int MarioInitalLife { get; } = 3;
        public static float CoinGravity { get; } = 0.1f;
        public static float CoinInitialVelocity { get; } = -1.5f;
        public static float ScoreTextGravity { get; } = 0.05f;
        public static float ScoreTextInitialVelocity { get; } = -1.5f;
        public static int FlagLine { get; } = 199;

        
    }
}
