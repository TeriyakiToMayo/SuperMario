﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Sprint1Game.Animation;
using Sprint1Game.Camera;
using Sprint1Game.CollisionHandling;
using Sprint1Game.Commands;
using Sprint1Game.DisplayPanel;
using Sprint1Game.GameObjects.ItemGameObjects;
using Sprint1Game.HeadsUp;
using Sprint1Game.Interfaces;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Sprint1Game.CollisionHandling.CollisionSide;
using static Sprint1Game.Controllers.GamePadController;
using static Sprint1Game.KeyboardController;

namespace Sprint1Game.GameObjects
{
    public class TheGameObjectManager
    {
        private ICollisionHandler collisionHandler;
        private Collection<IGameObject> blockList;
        private Collection<IGameObject> enemyList;
        private Collection<IGameObject> itemList;
        private Collection<IGameObject> pipeList;
        private Collection<IGameObject> fireBallList;
        private Collection<IGameObject> backgroundList;
        private Collection<IAnimationInGame> animationList;
        private IMario mario;
        private const int bufferSize = 32;
        private IAnimation victoryAnimation;
        private IController keyboard;
        private IGamePadController gamePad;

        private IDisplayPanel titleDisplayPanel;
        private IDisplayPanel marioLifeDisplayPanel;
        private IDisplayPanel gameOverDisplayPanel;
        private IDisplayPanel headsUpDisplayPanel;

        public IMario CurrentMario { get { return mario; } }
        
        public long FireBallListLongCount { get { return fireBallList.LongCount(); } }

        public TheGameObjectManager()
        {
            blockList = new Collection<IGameObject>();
            itemList = new Collection<IGameObject>();
            enemyList = new Collection<IGameObject>();
            pipeList = new Collection<IGameObject>();
            fireBallList = new Collection<IGameObject>();
            backgroundList = new Collection<IGameObject>();
            animationList = new Collection<IAnimationInGame>();
            collisionHandler = new AllCollisionHandler();

            titleDisplayPanel = new TitleDisplayPanel();
            marioLifeDisplayPanel = new MarioLifeDisplayPanel();
            gameOverDisplayPanel = new GameOverDisplayPanel();
            headsUpDisplayPanel = new HeadsUpDisplayPanel();
        }

        private bool isLevelComplete = false;

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
        public void Update()
        {
            if (GameUtilities.Game.State.Type == GameStates.Playing ||
                GameUtilities.Game.State.Type == GameStates.LevelComplete)
            {
                if (isMarioTransition)
                {
                    MarioTransitionUpdate();
                    return;
                }
                for (int i = 0; i < animationList.Count; i++)
                {
                    animationList[i].Update();
                }
                foreach (IGameObject obj in backgroundList)
                {
                    if (isInViewBackground(obj))
                        obj.Update();
                }
                foreach (IGameObject obj in blockList)
                {
                    if (isInView(obj))
                        obj.Update();
                }
                foreach (IEnemy obj in enemyList)
                {
                    if (isInView(obj) || obj.CanUpdate || !obj.Alive)
                        obj.Update();
                }
                foreach (IGameObject obj in itemList)
                {
                    obj.Update();
                }
                foreach (IGameObject obj in pipeList)
                {
                    if (isInView(obj))
                        obj.Update();
                }
                Collection<IGameObject> tempFireBallList = new Collection<IGameObject>();
                foreach (IGameObject obj in fireBallList)
                {
                    obj.Update();
                    FireBallProjectile fireBall = (FireBallProjectile)obj;
                    if (!fireBall.Used)
                    {
                        tempFireBallList.Add(obj);
                    }
                }
                fireBallList = tempFireBallList;
                mario.Update();
                mario.IsInAir = true;
                HandleCollisions();
                
                if (!isLevelComplete)
                {
                    if (mario.Destination.X + mario.Destination.Width >= GameUtilities.FlagLine * GameUtilities.BlockSize - GameUtilities.BlockSize / 2 &&
                        mario.Destination.X + mario.Destination.Width <= (GameUtilities.FlagLine + 1) * GameUtilities.BlockSize)
                    {
                        GameUtilities.Game.State.Proceed();
                        MarioAttributes.StopTimer();
                        isLevelComplete = true;
                        ScoringSystem.Instance.AddPointsForFinalPole(mario.Destination);
                        IItem flag_ = null;
                        foreach (IGameObject obj in itemList)
                        {
                            if (obj.GetType() == typeof(Flag))
                            {
                                flag_ = (IItem)obj;
                            }
                        }
                        victoryAnimation = new VictoryAnimation(mario, flag_);
                        victoryAnimation.State = AnimationState.IsPlaying;
                    }
                }
                else
                {
                    victoryAnimation.Update();
                }
            }

            titleDisplayPanel.Update();
            marioLifeDisplayPanel.Update();
            gameOverDisplayPanel.Update();
            headsUpDisplayPanel.Update();
            ScoringSystem.Instance.SetMarioEnemyHitThisIterationToFalse();
        }

        private bool isMarioTransition = false;
        private MarioState.MarioShapeEnums curShape;
        private MarioState.MarioShapeEnums nextShape_;

        public void MarioTransition(MarioState.MarioShapeEnums curShapePara, MarioState.MarioShapeEnums nextShape)
        {
            keyboard.IsFunctionKeysEnable = false;
            isMarioTransition = true;
            this.curShape = curShapePara;
            this.nextShape_ = nextShape;
            transitionTime = 30;
        }

        private int transitionTime = 0;

        public void MarioTransitionUpdate()
        {
            if (transitionTime == 0)
            {
                keyboard.IsFunctionKeysEnable = true;
                isMarioTransition = false;
            }
            if (transitionTime % 10 == 0)
            {
                MarioShapeChange(nextShape_);
            } else if (transitionTime % 5 == 0)
            {
                MarioShapeChange(curShape);
            }
            transitionTime--;
        }

        private void MarioShapeChange(MarioState.MarioShapeEnums newShape)
        {
            switch (newShape)
            {
                case MarioState.MarioShapeEnums.Big:
                    mario.State.ChangeSizeToBig();
                    break;
                case MarioState.MarioShapeEnums.Small:
                    mario.State.ChangeSizeToSmall();
                    break;
                case MarioState.MarioShapeEnums.Fire:
                    mario.State.ChangeFireMode();
                    break;
                case MarioState.MarioShapeEnums.StarBig:
                    mario.State.ChangeStarMode();
                    break;
                case MarioState.MarioShapeEnums.StarSmall:
                    mario.State.ChangeStarMode();
                    break;
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            foreach (IGameObject obj in backgroundList)
            {
                if (isInViewBackground(obj))
                    obj.Draw(spriteBatch);
            }
            foreach (IGameObject obj in itemList)
            {
                obj.Draw(spriteBatch);
            }
            foreach (IGameObject obj in blockList)
            {
                if (isInView(obj))
                    obj.Draw(spriteBatch);
            }
            foreach (IGameObject obj in pipeList)
            {
                if (isInView(obj))
                    obj.Draw(spriteBatch);
            }
            foreach (IGameObject obj in enemyList)
            {
                if (isInView(obj))
                    obj.Draw(spriteBatch);
            }
            foreach (IAnimationInGame obj in animationList)
            {
                if (obj.State == AnimationState.IsPlaying)
                    obj.Draw(spriteBatch);
            }
            foreach (IGameObject obj in fireBallList)
            {
                obj.Draw(spriteBatch);
            }
            mario.Draw(spriteBatch);

            titleDisplayPanel.Draw(spriteBatch);
            marioLifeDisplayPanel.Draw(spriteBatch);
            gameOverDisplayPanel.Draw(spriteBatch);
            headsUpDisplayPanel.Draw(spriteBatch);
        }

        public void AddBlock(IGameObject block)
        {
            blockList.Add(block);
        }

        public void AddItem(IGameObject item)
        {
            itemList.Add(item);
        }

        public void AddPipe(IGameObject pipe)
        {
            pipeList.Add(pipe);
        }

        public void AddEnemy(IGameObject enemy)
        {
            enemyList.Add(enemy);
        }

        public void AddBackgroundItem(IGameObject item)
        {
            backgroundList.Add(item);
        }

        public void AddFireBall(IProjectile fireBall)
        {
            fireBallList.Add(fireBall);
        }

        public void AddAnimation(IAnimationInGame animation)
        {
            animationList.Add(animation);
        }

        public void SetMario(IMario newMario)
        {
            this.mario = newMario;
        }

        public void AddKeyboardControllerCommands(IController keyboard_)
        {
            this.keyboard = keyboard_;
            keyboard.RegisterCommand(KeyboardKeys.Left, Keys.Left, new LeftMarioCommand(mario));
            keyboard.RegisterCommand(KeyboardKeys.A, Keys.Z, new MarioUpCommand(mario));
            keyboard.RegisterCommand(KeyboardKeys.B, Keys.X, new MarioAcceCommand(mario));
            keyboard.RegisterCommand(KeyboardKeys.Right, Keys.Right, new RightMarioCommand(mario));
            keyboard.RegisterCommand(KeyboardKeys.Down, Keys.Down, new MarioDownCommand(mario));
            keyboard.RegisterCommand(KeyboardKeys.Start, Keys.Enter, new EnterCommand((Game1)GameUtilities.Game));
            keyboard.RegisterCommand(KeyboardKeys.TestToSmall, Keys.Y, new MarioToSmallCommand(mario));
            keyboard.RegisterCommand(KeyboardKeys.TestToBig, Keys.U, new MarioToBigCommand(mario));
            keyboard.RegisterCommand(KeyboardKeys.TestToFire, Keys.I, new MarioToFireCommand(mario));
            keyboard.RegisterCommand(KeyboardKeys.TestToDead, Keys.O, new MarioToDeadCommand(mario));
            keyboard.RegisterCommand(KeyboardKeys.TestToStar, Keys.P, new MarioToStarCommand(mario));

            keyboard.RegisterReleasedCommand(KeyboardKeys.Left, Keys.Left, new ReleasedLeftMarioCommand(mario));
            keyboard.RegisterReleasedCommand(KeyboardKeys.Right, Keys.Right, new ReleasedRightMarioCommand(mario));
            keyboard.RegisterReleasedCommand(KeyboardKeys.Down, Keys.Down, new ReleasedDownMarioCommand(mario));
            keyboard.RegisterReleasedCommand(KeyboardKeys.B, Keys.X, new ReleasedAcceMarioCommand(mario));
            keyboard.RegisterReleasedCommand(KeyboardKeys.A, Keys.Z, new ReleasedUpMarioCommand(mario));
        }

        public void AddGamePadControllerCommands(IGamePadController gamePad_)
        {
            this.gamePad = gamePad_;
            gamePad.RegisterCommand(KeyboardKeys2.Left, Buttons.DPadLeft, new LeftMarioCommand(mario));
            gamePad.RegisterCommand(KeyboardKeys2.A, Buttons.A, new MarioUpCommand(mario));
            gamePad.RegisterCommand(KeyboardKeys2.B, Buttons.B, new MarioAcceCommand(mario));
            gamePad.RegisterCommand(KeyboardKeys2.Right, Buttons.DPadRight, new RightMarioCommand(mario));
            gamePad.RegisterCommand(KeyboardKeys2.Down, Buttons.DPadDown, new MarioDownCommand(mario));
            gamePad.RegisterCommand(KeyboardKeys2.Start, Buttons.Start, new MarioDownCommand(mario));

            gamePad.RegisterReleasedCommand(KeyboardKeys2.Left, Buttons.DPadLeft, new ReleasedLeftMarioCommand(mario));
            gamePad.RegisterReleasedCommand(KeyboardKeys2.Right, Buttons.DPadRight, new ReleasedRightMarioCommand(mario));
            gamePad.RegisterReleasedCommand(KeyboardKeys2.Down, Buttons.DPadDown, new ReleasedDownMarioCommand(mario));
            gamePad.RegisterReleasedCommand(KeyboardKeys2.B, Buttons.B, new ReleasedAcceMarioCommand(mario));
            gamePad.RegisterReleasedCommand(KeyboardKeys2.A, Buttons.A, new ReleasedUpMarioCommand(mario));
        }

        private static bool isInView(IGameObject obj)
        {
            return obj.Location.X >= Camera2D.CameraX - bufferSize && obj.Location.X <= Camera2D.CameraX + 2 * Camera2D.CenterOfScreen;
        }

        private static bool isInViewBackground(IGameObject obj)
        {
            return obj.Location.X >= Camera2D.CameraX - 2.5 * bufferSize && obj.Location.X <= Camera2D.CameraX + 2 * Camera2D.CenterOfScreen + 2.5 * bufferSize;
        }

        private void HandleCollisions()
        {
            HandleObjectCollisions.HandleCollisions(collisionHandler, mario, blockList, enemyList, itemList, pipeList, fireBallList);
        }
    }
}
