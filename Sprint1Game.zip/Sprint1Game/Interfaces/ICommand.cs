﻿using Sprint1Game.Interfaces;

namespace Sprint1Game
{
    public interface ICommand
    {
        void Execute();
    }
}
